"""
Pasta de plugins do Telegram Userbot

Coloque seus plugins personalizados aqui.
Cada plugin deve ter uma função setup(bot, Config, stats, safe_send, safe_edit)
"""

__all__ = []